This directory contains log files produced by the various programs executed during your experiment.

For support, please contact:
	ipp-support@cbica.upenn.edu
